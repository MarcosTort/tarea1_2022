/* abcdefg */ // sustituiir con los 7 dígitos de la cédula

#include "../include/colCadenas.h"

struct _rep_colCadenas {};

TColCadenas crearColCadenas() {
  return NULL;
}

/* en siguientes tareas
void liberarColCadenas(TColCadenas col) {
}
*/
nat cantidadColCadenas(nat pos, TColCadenas col) {
  return 0;
}

bool estaEnColCadenas(nat natural, nat pos, TColCadenas col) {
  return false;
}

TColCadenas insertarEnColCadenas(nat natural, double real, nat pos,
                                 TColCadenas col) {
  return NULL;
}

TInfo infoEnColCadenas(nat natural, nat pos, TColCadenas col) {
  return NULL;
}

TColCadenas removerDeColCadenas(nat natural, nat pos, TColCadenas col) {
  return NULL;
}
